# Group 34 · Humanoid robotics patent landscape

This project follows humanoid platforms, dedicated parts and controllers, and related robotics in PATSTAT PROD from 2000 through 2022. It starts with 176,342 distinct DOCDB families. One family can have several patent applications.

## Run the notebooks

On TIP, open the notebooks from the project folder. To run locally, install the packages in `requirements.txt` and start JupyterLab from this folder.

```bash
python -m pip install -r requirements.txt
python -m jupyterlab
```

| Notebook | What it does | Where to look |
| --- | --- | --- |
| [00 · Retrieval](00_retrieval.ipynb) | Shows Thomas's original keyword, CPC and IPC search and the completed PROD source. | `config/` |
| [01 · Classification](01_classification.ipynb) | Combines Leo's rule, targeted phrases, Patent SBERT scores and recorded review decisions. | `results/full_classification.csv.gz` |
| [02 · Landscape](02_landscape.ipynb) | Applies Imma's volume, retrieval overlap and technology mix analyses to the three categories and their union. | `results/segmented_*` |
| [03 · Companies](03_companies.ipynb) | Compares applicant concentration and compares growth and stability across 15 selected portfolios. | `results/applicant_concentration.csv`, `results/company_profiles.csv` |

The bundled notebooks default to reading the precomputed results. They can run in order without a PATSTAT session.

## What enters the analysis

| Category | Definition | Families |
| --- | --- | ---: |
| Humanoid platforms | The invention is about the humanoid robot as a whole. | 170 |
| Dedicated components and controllers | The invention is a part or controller explicitly designed for a humanoid. | 543 |
| Related robotics | Similar robots and general robotic technologies, such as a generic robotic hand. | 71,294 |
| Combined | The three categories above, counted once per family. | 72,007 |

The strict scope combines the first two rows. Uncertain and out-of-scope decisions remain visible in the full classification. Most decisions use automatic screening of title and abstract and 327 use recorded reviews. The counts describe this corpus and its classification rules.

Step 2 applies the same periods, 2000–2007, 2008–2014 and 2015–2022, to each view. Volumes are annualized for comparison. CPC and IPC use one family per assigned subclass or main group, with a separate coverage table. Each code share uses all families in the view as its denominator.

## Results at a glance

The 2015–2022 period averaged 13.8 platform families, 41.6 dedicated component and controller families, and 6,893 related robotics families per year. The combined average was 6,948.4 per year. See [volumes by period](results/segmented_volumes.csv) and the [CPC and IPC charts](results/segmented_top_cpc_ipc.png).

PATSTAT provided a named applicant for 71,793 of the 72,007 combined families. The top four applicants account for 15.6% of named platform families, 19.9% of named dedicated families, and 3.5% of the combined view. See [applicant concentration](results/applicant_concentration.csv).

Among the selected companies, UBTECH and Samsung Electronics increased their average annual fractional patenting by 43.25 and 34.62 families, respectively, between the two four-year windows. The [company profiles](results/company_profiles.csv) and [annual chart](results/company_patenting.png) show portfolios, growth and patenting continuity.

## How the 15 companies are chosen

The company panel uses PATSTAT's `COMPANY` sector flag. Eligible applicants have two active years, at least three fractional families in the combined view and at least one strict-scope family. A family with two named applicants gives half a family to each. The [alias list](data/applicant_aliases.csv) resolves spelling variants for leading applicants before weights are assigned. Subsidiaries and unresolved variants may appear separately. [EPO PATSTAT Global data catalogue](https://link.epo.org/web/business/patstat/en-data-catalog-patsat-global-autumn-2025.pdf)

- **Recent entrants** are the five largest eligible portfolios first observed in the corpus from 2015 onward. The entry year is the first observed patent year in this dataset.
- **Medium portfolios** are the five established portfolios nearest the eligible established median after taking out the five largest.
- **Large portfolios** are the five largest eligible portfolios first observed before 2015.

Portfolio size is the number of fractional families in this project. Growth compares patents per year in 2015–2018 and 2019–2022. Stability uses the share of years with activity and the variation of annual filing counts since first observation. CR4, CR8, HHI and Gini use all named applicants with coverage reported alongside them.

The recorded country is the most frequent populated PATSTAT country for the normalized applicant in this cohort. The applicant view uses PI members of each DOCDB family and captures names attached to those members. It describes patent applicant portfolios at extraction time.

References for selected alias decisions include the corporate profiles of UBTECH, THK, Kawasaki and Yaskawa, and Alphabet's 2017 filing for the Google Inc. to Google LLC conversion. [UBTECH](https://www.ubtrobot.com/en/about/company-profile) · [THK](https://www.thk.com/jp/en/products/catalog/pub/cp1_companyprofile.pdf) · [Kawasaki](https://www.khi.co.jp/corporate/outline.html) · [Yaskawa](https://www.yaskawa.co.jp/wp-content/uploads/2022/05/teikan220526.pdf) · [Alphabet 2017 Form 10-K](https://www.sec.gov/Archives/edgar/data/1652044/000165204418000007/goog10-kq42017.htm)

## Rebuild with saved inputs

Keep the original Step 0 export and the saved Leo and semantic outputs in TIP. In each notebook set `TIP_PROJECT` to the project that holds the existing `outputs/pipeline` and `outputs/semantic` directories. Set `PROD_FOLDER` if your original Step 0 export is stored elsewhere.

- To rebuild the classification from saved scores, enable `REBUILD` in Step 1.
- To rebuild volumes, code mix and retrieval routes, enable `REBUILD_TABLES` in Step 2.
- To fetch filing years and applicant links, enable `FETCH_FROM_TIP` once in Step 3. For subsequent runs, use the cached export in `inputs/`.

Keep raw PATSTAT exports and any credentials in your local or TIP workspace. The repository ships derived results and recorded review evidence. The technical handoff for coding agents is in [AGENTS.md](AGENTS.md).

"""Repeat the period and CPC/IPC analyses for three categories and their union."""

import pandas as pd

from full_classification import STRICT
from schema import FAMILY, PERIODS


SEGMENTS = [*STRICT, "affine"]
ALL = "combined"
GROUPS = [*SEGMENTS, ALL]
NAMES = dict(zip(GROUPS, ["Humanoid platforms", "Dedicated components", "Related robotics", "Combined"]))
YEARS = {period: int(period[-4:]) - int(period[:4]) + 1 for period in PERIODS}


def read_scope(root):
    scope = pd.read_csv(root / "results/full_classification.csv.gz", usecols=[FAMILY, "period", "category", "technology"])
    if not scope[FAMILY].is_unique or not scope.period.isin(PERIODS).all():
        raise ValueError("The classification must contain unique families and valid filing periods.")
    return scope.loc[scope.category.isin(SEGMENTS)].rename(columns={"category": "group"})


def with_combined(scope):
    return pd.concat([scope, scope.assign(group=ALL)], ignore_index=True)


def technology_tables(codes_path, scope, totals):
    blocks = []
    for frame in pd.read_csv(codes_path, usecols=[FAMILY, "scheme", "code"], chunksize=250_000):
        frame = frame.loc[frame[FAMILY].isin(scope[FAMILY]) & frame.scheme.isin(["CPC", "IPC"])]
        symbols = frame.code.astype("string").str.upper().str.replace(r"\s+", "", regex=True)
        main = symbols.str.extract(r"^([A-Z]\d{2}[A-Z]\d+)/\d+$", expand=False) + "/00"
        subclass = symbols.str.extract(r"^([A-Z]\d{2}[A-Z])(?:\d+/\d+)?$", expand=False)
        blocks.append(frame[[FAMILY, "scheme"]].assign(subclass=subclass, main_group=main).drop_duplicates())
    codes = pd.concat(blocks, ignore_index=True).drop_duplicates().merge(scope, on=FAMILY, validate="many_to_one")
    codes = with_combined(codes)
    mix, coverage = [], []
    group_keys = ["group", "period", "scheme"]
    for level in ("subclass", "main_group"):
        pairs = codes[[FAMILY, *group_keys, level]].dropna().drop_duplicates()
        counts = (pairs.groupby([*group_keys, level], as_index=False)[FAMILY].nunique()
                  .rename(columns={FAMILY: "families", level: "code"}))
        counts = counts.join(totals, on=["group", "period"])
        counts["share_pct"] = 100 * counts.families / counts.all_families
        mix.append(counts.assign(level=level))
        found = pairs.groupby(group_keys)[FAMILY].nunique()
        coverage_index = pd.MultiIndex.from_product([GROUPS, PERIODS, ["CPC", "IPC"]], names=group_keys)
        found = found.reindex(coverage_index, fill_value=0).rename("families_with_code").reset_index()
        found = found.join(totals, on=["group", "period"])
        found["coverage_pct"] = 100 * found.families_with_code / found.all_families
        coverage.append(found.assign(level=level))
    return pd.concat(mix, ignore_index=True), pd.concat(coverage, ignore_index=True)


def retrieval_routes(hits_path, scope):
    membership = pd.read_csv(hits_path, usecols=[FAMILY, "lane"]).drop_duplicates()
    membership = membership.loc[membership[FAMILY].isin(scope[FAMILY])]
    if not membership.lane.isin(["keywords", "CPC", "IPC"]).all() or not scope[FAMILY].isin(membership[FAMILY]).all():
        raise ValueError("Use the original Step 0 hit export with keyword, CPC and IPC lanes.")
    combinations = (membership.groupby(FAMILY).lane.agg(lambda lanes: " + ".join(sorted(lanes)))
                    .rename("routes"))
    rows = with_combined(scope).join(combinations, on=FAMILY)
    return rows.groupby(["group", "period", "routes"], as_index=False)[FAMILY].size().rename(
        columns={"size": "families"}
    )


def analyze_segments(root, codes_path, hits_path=None):
    results = root / "results"
    scope = read_scope(root)
    index = pd.MultiIndex.from_product([GROUPS, PERIODS], names=["group", "period"])
    totals = with_combined(scope).groupby(["group", "period"]).size().reindex(index, fill_value=0).rename("all_families")
    volumes = totals.reset_index()
    volumes["years"] = volumes.period.map(YEARS)
    volumes["families_per_year"] = volumes.all_families / volumes.years
    previous = volumes.groupby("group", sort=False).families_per_year.shift()
    volumes["change_in_annual_rate_pct"] = 100 * (volumes.families_per_year / previous.where(previous.gt(0)) - 1)
    combined = volumes.loc[volumes.group.eq(ALL)].set_index("period").all_families
    volumes["share_of_combined_pct"] = 100 * volumes.all_families / volumes.period.map(combined)
    volumes.to_csv(results / "segmented_volumes.csv", index=False)
    technology = scope.assign(technology=scope.technology.fillna("unspecified"))
    invention_counts = (technology.groupby(["period", "group", "technology"], as_index=False)[FAMILY]
                        .size().rename(columns={"size": "families", "group": "category"}))
    invention_counts.to_csv(results / "full_by_technology.csv", index=False)
    plot_volumes(volumes, results / "segmented_volumes.png")
    if codes_path is not None:
        mix, coverage = technology_tables(codes_path, scope, totals)
        mix = mix.sort_values(["families", "code"], ascending=[False, True])
        top = mix.groupby(["group", "period", "scheme", "level"], sort=False).head(10)
        mix.to_csv(results / "segmented_code_mix.csv.gz", index=False, compression="gzip")
        top.to_csv(results / "segmented_top_codes.csv", index=False)
        coverage.to_csv(results / "segmented_code_coverage.csv", index=False)
        plot_top_codes(top, results / "segmented_top_cpc_ipc.png")
    if hits_path is not None:
        retrieval_routes(hits_path, scope).to_csv(results / "segmented_search_routes.csv", index=False)
    return volumes


def plot_volumes(volumes, path):
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(2, 2, figsize=(10, 7), layout="constrained")
    for axis, group, color in zip(axes.flat, GROUPS, ["#216278", "#3d8d7e", "#9d6d39", "#44566d"]):
        data = volumes.loc[volumes.group.eq(group)]
        bars = axis.bar(data.period, data.families_per_year, color=color, width=0.6)
        axis.bar_label(bars, labels=[f"{v:,.1f}" for v in data.families_per_year], padding=4)
        axis.margins(y=0.22)
        axis.set_title(NAMES[group], loc="left")
        axis.set_ylabel("DOCDB families per year")
        axis.spines[["top", "right"]].set_visible(False)
    fig.suptitle("Patent volumes by filing period")
    fig.savefig(path, dpi=170)
    plt.close(fig)


def plot_top_codes(top, path):
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(4, 2, figsize=(10, 11), layout="constrained")
    latest = top.loc[top.period.eq(PERIODS[-1]) & top.level.eq("main_group")]
    for group, row in zip(GROUPS, axes):
        for axis, scheme, color in zip(row, ["CPC", "IPC"], ["#216278", "#3d8d7e"]):
            data = latest.loc[latest.group.eq(group) & latest.scheme.eq(scheme)].head(5).iloc[::-1]
            bars = axis.barh(data.code, data.share_pct, color=color)
            axis.bar_label(bars, labels=[f"{v:.1f}%" for v in data.share_pct], padding=4)
            axis.set_xlim(0, 100)
            axis.set_title(f"{NAMES[group]} · {scheme}", loc="left")
            axis.spines[["top", "right"]].set_visible(False)
    fig.supxlabel("Share of all classified families in the category")
    fig.suptitle(f"Leading assigned technology groups · {PERIODS[-1]}")
    fig.savefig(path, dpi=165)
    plt.close(fig)

"""Shared family fields, filing periods and technology terms."""

FAMILY = "docdb_family_id"
PERIODS = ["2000-2007", "2008-2014", "2015-2022"]

TOPICS = {
    "platform": (5, r"\b(?:humanoid|android|biped(?:al)?|two[- ]legged|human[- ](?:like|shaped)|torso|whole[- ]body)\b"),
    "control_locomotion": (5, r"\b(?:gait|locomotion|stance|balance control|zero moment point|motion planning|walking control|fall control)\b"),
    "hand": (4, r"\b(?:hands?|fingers?|palm|knuckles?|phalanges|phalangeal|interphalangeal)\b"),
    "foot": (4, r"\b(?:feet|foot|ankles?|sole|heel|toe)\b"),
    "shoulder": (4, r"\b(?:shoulders?|scapul[ae]|clavicl[ae]s?)\b"),
    "arm": (4, r"\b(?:arms?|forearms?|elbows?)\b"),
    "joint": (4, r"\b(?:joints?|articulations?|actuators?|wrist|transmission)\b"),
}

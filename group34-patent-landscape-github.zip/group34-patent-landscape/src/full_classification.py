"""Classify the entire saved PROD cohort using text, Leo's rule and Patent SBERT."""

import json
import re
from pathlib import Path
from unicodedata import normalize

import pandas as pd

from schema import FAMILY, PERIODS, TOPICS


CATEGORIES = ["humanoid_platform", "dedicated_component", "affine", "out_of_scope", "uncertain"]
STRICT = CATEGORIES[:2]
SOURCE_RUN = "search_20261116T232020043130Z_THROUGH_2022_PROD"
SBERT_REVIEW_THRESHOLD = 0.90

# The wording must identify a humanoid robot, regardless of its locomotion.
FORM = (
    r"\b(?:(?:biped(?:al)?\s+)?humanoid\s+"
    r"(?:(?:biped(?:al)?|walking|musculoskeletal|lower body|upper body|mobile|service|stair climbing)\s+){0,3}"
    r"(?:robot(?:s|ic\s+(?:platform|system))?|platforms?|machines?)"
    r"|(?:android|anthropomorphic|human[- ](?:like|shaped|form|type|simulat(?:ed|ing))|humanlike)\s+"
    r"(?:(?:mobile|biped(?:al)?|walking)\s+){0,3}robots?"
    r"|robot(?:s)?\s+of\s+(?:a\s+)?humanoid\s+(?:form|type|shape))\b"
)
HUMANOID = re.compile(r"\bhumanoids?\b|" + FORM)
ROBOT = re.compile(r"\b(?:robots?|robotics?|humanoids?)\b")
ADJACENT = re.compile(
    r"\b(?:biped(?:s|al)?|quadrupeds?|hexapods?|multipeds?|legged robot|robot(?:ic)? (?:dog|pet)|"
    r"(?:two|four|six|multi)[- ]legged)\b"
)
EXCLUSION = re.compile(
    r"\b(?:exoskeletons?|exosuits?|prosthe\w+|crash[- ]test dumm\w+|mannequins?|"
    r"toy robots?|robotic toys?|toy figures?|dolls?|puppets?|robotic fish|robot fish|"
    r"(?:wall|pipe|tower|tree|pole)[- ]climbing robots?|unmanned drones?)\b"
)
INTRO = re.compile(
    r"^(?:the\s+)?(?:present\s+)?(?:invention|disclosure|utility model)\s+"
    r"(?:(?:herein\s+)?(?:relates to|discloses|provides|describes|presents|proposes)|"
    r"(?:is|belongs)\s+(?:directed )?to)\s+"
)
LEADING_WORDS = (
    r"(?:(?:a|an|the)\s+)?(?:(?:novel|improved|intelligent|mini|lightweight|"
    r"simulated|full[- ]size|remote(?:ly controlled)?)\s+){0,3}"
)
PLATFORM_SUBJECT = re.compile(r"^" + LEADING_WORDS + FORM)
# Words that express an invention's function or a component's intended host.
HOST = re.compile(
    r"\b(?:for|of|on|in|applied to|mounted on|adapted to|used (?:on|in|by))\s+"
    + LEADING_WORDS + r"(?:" + FORM + r"|humanoids?\b(?=$|[,.]|\s+(?:against|under|in|during|with)\b))"
)
BODY = re.compile(
    r"\b(?:torso|trunk|legs?|knees?|thighs?|shins?|hips?|pelvis|head|neck|waist|"
    r"grippers?|manipulators?|end effectors?|cooling system|drive mechanism)\b"
)
SUBSYSTEM = re.compile(
    r"\b(?:controllers?|control (?:methods?|systems?|devices?|apparat\w+)|"
    r"methods? (?:for|of|to)|subassembl\w+|mechanisms?|sensor systems?|"
    r"force[- ]feedback (?:devices?|systems?)|tactile sensors?|power supplies)\b"
)
BACKGROUND = re.compile(
    r"\b(?:such as|e\.g\.|for example|including but not limited to|(?:technical )?field of|"
    r"prior art|conventional|existing)\s+" + LEADING_WORDS + FORM
)
TEST_EQUIPMENT = re.compile(r"\b(?:test(?:ing)?\s+(?:rig|bench|device|arrangement)|tester)\b")
TOPIC_PATTERNS = {
    key: re.compile(expression) for key, (_, expression) in TOPICS.items() if key != "platform"
}
TOPIC_PATTERNS.update({
    "leg": re.compile(r"\b(?:legs?|knees?|thighs?|shins?)\b"),
    "head_neck": re.compile(r"\b(?:heads?|necks?|face)\b"),
    "torso": re.compile(r"\b(?:torso|trunk|waist)\b"),
    "other_component": re.compile(r"\b(?:grippers?|manipulators?|end effectors?|cooling system)\b"),
})
TOPIC_PATTERNS["control_locomotion"] = re.compile(
    TOPICS["control_locomotion"][1] + r"|\b(?:fall direction|stepping|bipedal control|"
    r"posture control|humanoid (?:robot )?control)\b"
)
HTML = re.compile(r"</?[a-z][^>]*>", re.IGNORECASE)
SENTENCES = re.compile(r"(?<=[.!?])\s+")
REVIEW_LABELS = {"adjacent_robotics": "affine", "out_of_scope": "out_of_scope", "uncertain": "uncertain"}


def clean(text):
    text = HTML.sub(" ", normalize("NFKC", text)).translate(str.maketrans("‐‑–—", "----"))
    return " ".join(text.lower().split())


def technology(text):
    found = [(match.start(), name) for name, pattern in TOPIC_PATTERNS.items() if (match := pattern.search(text))]
    return min(found)[1] if found else ""


def dedicated_or_platform(text):
    """Recognize explicit evidence in a title or a sentence about the invention."""
    text = INTRO.sub("", text).removeprefix("solution: ").removeprefix("to provide ")
    if BACKGROUND.search(text) or TEST_EQUIPMENT.search(text):
        return "", ""
    topic = technology(text)
    for host in HOST.finditer(text):
        prefix = text[:host.start()]
        if len(prefix) > 170:
            continue
        if technology(prefix) or SUBSYSTEM.search(prefix) or BODY.search(prefix):
            return "dedicated_component", technology(prefix) or topic or "other_component"

    # A title can name a subsystem together with the platform using it.
    if re.match(r"^.{1,110}\band\s+" + LEADING_WORDS + FORM, text) and topic:
        return "dedicated_component", topic

    subject = PLATFORM_SUBJECT.match(text)
    if subject:
        tail = text[subject.end():].lstrip(" '’:-")
        if re.match(r"(?:with|having|has|have|including|includes?|compris\w+|equipped|using|based)\b", tail):
            return "humanoid_platform", "platform"
        if topic or SUBSYSTEM.search(tail):
            return "dedicated_component", topic or "other_component"
        return "humanoid_platform", "platform"
    # Explicit labels such as "humanoid five-finger manipulator".
    if re.match(r"^humanoid\s+", text) and topic:
        return "dedicated_component", topic
    return "", ""


def classify_text(title, abstract, leo, robotics_cpc, semantic, threshold):
    title = clean(title)
    abstract = clean(abstract)
    opening = SENTENCES.split(abstract[:1100], maxsplit=2)[:2]
    fields = [("title", title), *(("abstract", sentence) for sentence in opening)]
    sbert = pd.notna(semantic) and semantic >= threshold
    target_text = title + " " + abstract
    explicit = bool(HUMANOID.search(target_text))
    topic = technology(title) or technology(" ".join(opening))
    robotic_context = bool(ROBOT.search(target_text) or robotics_cpc)
    related_form = bool(ADJACENT.search(title) or ADJACENT.search(" ".join(opening)))
    keywords = explicit or related_form or bool(topic and robotic_context)

    if not (title or abstract):
        return "uncertain", "", "no_title_or_abstract", "", keywords
    # A toy or a wearable device named in the title is normally outside the sector.
    excluded = {line for _, line in fields if EXCLUSION.search(line)}
    exclusion_text = next((line for _, line in fields if line in excluded), "")
    excluded_title = title in excluded
    operator_interface = bool(explicit and HUMANOID.search(title)
                              and re.search(r"\b(?:remote control|teleoperat\w*)\b", title))
    if explicit:
        for field, text in fields:
            if (excluded_title or text in excluded) and not operator_interface:
                continue
            category, invention = dedicated_or_platform(text)
            if category:
                return category, invention, f"explicit_humanoid_use_{field}", text[:420], keywords
    if exclusion_text and not operator_interface and (excluded_title or not (explicit or related_form)):
        return "out_of_scope", topic, "excluded_invention", exclusion_text[:420], keywords
    if explicit:
        match = HUMANOID.search(target_text)
        excerpt = target_text[max(0, match.start() - 75):match.end() + 100]
        return "uncertain", topic, "humanoid_mention_requires_context", excerpt, keywords
    if related_form or (topic and robotic_context):
        return "affine", topic, "related_robot_or_general_component", (title or abstract)[:420], keywords
    if leo or sbert:
        reason = "leo_and_semantic_signal" if leo and sbert else "leo_signal" if leo else "semantic_signal"
        return "uncertain", topic, reason, "", keywords
    return "out_of_scope", topic, "no_qualifying_signal_in_available_text", "", keywords


def read_cohort(text_path, rank_path, baseline_path, periods_path):
    rank = pd.read_csv(rank_path, usecols=[FAMILY, "title", "semantic", "leo_rule", "nearest_reference"],
                       dtype={FAMILY: "int64", "nearest_reference": "Int64", "leo_rule": "boolean"})
    baseline = pd.read_csv(baseline_path, usecols=[FAMILY, "robotics_cpc"],
                           dtype={FAMILY: "int64", "robotics_cpc": "boolean"})
    periods = pd.read_csv(periods_path, usecols=[FAMILY, "period"], dtype={FAMILY: "int64"})
    texts = pd.read_csv(text_path, usecols=[FAMILY, "title", "abstract"], keep_default_na=False,
                        dtype={FAMILY: "int64", "title": str, "abstract": str})
    ids = pd.Index(rank[FAMILY])
    for name, frame in [("ranking", rank), ("Leo baseline", baseline), ("periods", periods)]:
        if not frame[FAMILY].is_unique or set(frame[FAMILY]) != set(ids):
            raise ValueError(f"{name} must have exactly one row per family in the saved rank file.")
    if ids.empty or (ids <= 0).any() or rank.leo_rule.isna().any() or baseline.robotics_cpc.isna().any():
        raise ValueError("A valid cohort needs positive family IDs and complete classification flags.")
    if not periods.period.isin(PERIODS).all():
        raise ValueError("The filing-period table has unexpected values.")
    if not rank.semantic.dropna().between(-1.00001, 1.00001).all():
        raise ValueError("The saved semantic column must contain cosine similarities.")

    # The local text download can cover extra years. Match the frozen 2022 cohort by ID and title.
    texts = texts.loc[texts[FAMILY].isin(ids)]
    merged = rank.merge(texts, on=FAMILY, suffixes=("", "_source"), validate="one_to_one")
    titles = merged.title.fillna("").str.split().str.join(" ")
    source_titles = merged.title_source.str.split().str.join(" ")
    if len(merged) != len(rank) or not titles.eq(source_titles).all():
        raise ValueError("The text export must cover the full ranked cohort with matching titles.")
    return (merged.drop(columns="title_source").fillna({"title": ""})
            .merge(baseline, on=FAMILY, validate="one_to_one")
            .merge(periods, on=FAMILY, validate="one_to_one")
            .sort_values(FAMILY, ignore_index=True))


def apply_review(result, root):
    review = pd.read_csv(root / "data/reviewed_families.csv", keep_default_na=False,
                         usecols=[FAMILY, "manual_label", "evidence", "review_status",
                                  "technology", "claims_publication", "claims_status"])
    reviewed_tech = pd.read_csv(root / "data/reviewed_technology.csv", keep_default_na=False)
    review = review.merge(reviewed_tech, on=FAMILY, how="left", validate="one_to_one")
    review["technology"] = review.technology.mask(review.technology.eq(""), review.technology_from_evidence)
    if (not review[FAMILY].isin(result[FAMILY]).all()
            or not review.manual_label.isin([*REVIEW_LABELS, "humanoid"]).all()
            or review.evidence.str.strip().eq("").any()):
        raise ValueError("Saved reviews must refer to cohort families with a valid label and reason.")
    if review.loc[review.manual_label.eq("humanoid"), "technology"].fillna("").isin(["", "other", "uncertain"]).any():
        raise ValueError("Every reviewed humanoid needs a platform or dedicated technology label.")
    result = result.merge(review, on=FAMILY, how="left", suffixes=("", "_review"), validate="one_to_one")
    selected = result.manual_label.notna()
    humanoid = result.manual_label.eq("humanoid")
    result.loc[selected & ~humanoid, "category"] = result.loc[selected & ~humanoid, "manual_label"].map(REVIEW_LABELS)
    result.loc[humanoid, "category"] = "dedicated_component"
    result.loc[humanoid & result.technology_review.eq("platform"), "category"] = "humanoid_platform"
    known_technology = selected & result.technology_review.fillna("").ne("")
    result.loc[known_technology, "technology"] = result.loc[known_technology, "technology_review"]
    result.loc[selected, "decision_basis"] = "recorded_review"
    result.loc[selected, "evidence_excerpt"] = result.loc[selected, "evidence"]
    result.loc[selected, "decision_source"] = result.loc[selected, "review_status"]
    return result.drop(columns=["technology_review", "technology_from_evidence", "evidence", "review_status"])


def classify(root, text_path, rank_path, baseline_path, periods_path, threshold=SBERT_REVIEW_THRESHOLD,
             source_run=SOURCE_RUN):
    if not 0 <= threshold <= 1:
        raise ValueError("The similarity threshold must be between 0 and 1.")
    cohort = read_cohort(text_path, rank_path, baseline_path, periods_path)
    outcomes = [
        classify_text(row.title, row.abstract, row.leo_rule, row.robotics_cpc, row.semantic, threshold)
        for row in cohort.itertuples(index=False)
    ]
    labels = pd.DataFrame(outcomes, columns=["category", "technology", "decision_basis",
                                             "evidence_excerpt", "targeted_keywords"])
    labels = pd.concat([cohort.drop(columns="abstract"), labels], axis=1)
    labels["patent_sbert_signal"] = labels.semantic.ge(threshold)
    labels["signal_union"] = labels[["leo_rule", "targeted_keywords", "patent_sbert_signal"]].any(axis=1)
    labels["decision_source"] = "automatic"
    labels["automatic_category"] = labels.category
    labels = apply_review(labels, root)
    labels["strict_scope"] = labels.category.isin(STRICT)
    labels["extended_scope"] = labels.category.isin([*STRICT, "affine"])
    assert labels[FAMILY].is_unique and len(labels) == len(cohort) and labels.category.isin(CATEGORIES).all()

    results = root / "results"
    results.mkdir(exist_ok=True)
    manifest = {
        "method": "full_prod_hybrid_v1",
        "source_run": source_run,
        "families": len(labels),
        "families_with_sbert_score": int(labels.semantic.notna().sum()),
        "signal_union_families": int(labels.signal_union.sum()),
        "sbert_review_threshold": threshold,
        "recorded_reviews": int(labels.manual_label.notna().sum()),
        "recorded_claim_support": int(labels.claims_status.eq("supports_relevance").sum()),
        "automatic_families": int(labels.decision_source.eq("automatic").sum()),
        "strict_scope": int(labels.strict_scope.sum()),
        "extended_scope": int(labels.extended_scope.sum()),
        "category_totals": labels.category.value_counts().reindex(CATEGORIES, fill_value=0).to_dict(),
    }
    labels.to_csv(results / "full_classification.csv.gz", index=False, compression="gzip")
    (results / "full_classification_manifest.json").write_text(
        json.dumps(manifest, indent=2) + "\n", encoding="utf-8"
    )
    return labels

"""Describe applicant concentration and compare 15 corporate patent portfolios."""

import json
from textwrap import fill
from zipfile import ZIP_DEFLATED, ZipFile

import numpy as np
import pandas as pd

from full_classification import SOURCE_RUN
from schema import FAMILY, PERIODS
from segmented_analysis import ALL, GROUPS, read_scope, retrieval_routes, with_combined


FIRST_YEAR, LAST_YEAR = 2000, 2022
ENTRY_YEAR = 2015
RECENT_WINDOW = (2019, 2022)
PREVIOUS_WINDOW = (2015, 2018)
FULL_PERIOD = "2000-2022"
NAME_FIELDS = ["han_name", "psn_name", "doc_std_name", "person_name"]


def fetch_applicant_source(root, prod):
    """Fetch the filing years and named applicants once from the existing PROD cohort."""
    from epo.tipdata.patstat import PatstatClient
    from epo.tipdata.patstat.database.models import TLS201_APPLN as A, TLS206_PERSON as P, TLS207_PERS_APPLN as L

    if prod.name != SOURCE_RUN:
        raise ValueError(f"Use the original Step 0 export {SOURCE_RUN}.")
    scope = read_scope(root)
    hits = pd.read_csv(prod / "retrieval_hits.csv", usecols=[FAMILY, "appln_id", "lane"])
    hits = hits.loc[hits[FAMILY].isin(scope[FAMILY])]
    hit_apps = hits[[FAMILY, "appln_id"]].drop_duplicates()
    ids = sorted(map(int, scope[FAMILY]))
    if set(hit_apps[FAMILY]) != set(ids):
        raise ValueError("The Step 0 export is missing families from the analysis.")
    client = PatstatClient(env="PROD")
    db = client.orm()
    year_query = db.query(A.docdb_family_id.label(FAMILY), A.appln_id,
                          A.earliest_filing_year.label("filing_year")).filter(A.ipr_type == "PI")
    person_query = (
        db.query(A.docdb_family_id.label(FAMILY), P.han_id, P.han_name, P.psn_name,
                 P.doc_std_name, P.person_name, P.psn_sector, P.person_ctry_code)
        .select_from(A).join(L, A.appln_id == L.appln_id).join(P, L.person_id == P.person_id)
        .filter(A.ipr_type == "PI", A.appln_id > 0, A.appln_id < 900_000_000, L.applt_seq_nr > 0)
        .distinct()
    )
    years, people = [], []
    for offset in range(0, len(ids), 4000):
        batch = ids[offset:offset + 4000]
        condition = A.docdb_family_id.in_(batch)
        dated = client.df(year_query.filter(condition)).merge(
            hit_apps, on=[FAMILY, "appln_id"], validate="one_to_one"
        )
        years.append(dated.groupby(FAMILY, as_index=False).filing_year.min())
        people.append(normalize_names(client.df(person_query.filter(condition))))
        print(f"Checked {offset + len(batch):,}/{len(ids):,} families", flush=True)

    dates = pd.concat(years, ignore_index=True)
    if not dates[FAMILY].is_unique or set(dates[FAMILY]) != set(ids):
        raise ValueError("Missing filing years for some selected families.")
    applicants = pd.concat(people, ignore_index=True).drop_duplicates()
    destination = root / "inputs/applicant_source_2000_2022.zip"
    destination.parent.mkdir(exist_ok=True)
    temporary = destination.with_suffix(".tmp")
    with ZipFile(temporary, "w", compression=ZIP_DEFLATED) as zip_file:
        zip_file.writestr("filing_years.csv", dates.to_csv(index=False))
        zip_file.writestr("applicant_links.csv", applicants.to_csv(index=False))
        zip_file.writestr("retrieval_routes.csv", hits[[FAMILY, "lane"]].drop_duplicates().to_csv(index=False))
        zip_file.writestr("source_run.txt", prod.name)
    temporary.replace(destination)
    return destination


def normalize_names(rows):
    if rows.empty:
        return pd.DataFrame(columns=[FAMILY, "applicant", "sector", "country"])
    names = rows[NAME_FIELDS].fillna("").astype(str)
    names = names.apply(lambda field: field.str.normalize("NFKC").str.split().str.join(" ").str.upper())
    names["han_name"] = names.han_name.where(pd.to_numeric(rows.han_id, errors="coerce").gt(0), "")
    best_name = names.replace("", pd.NA).bfill(axis=1).iloc[:, 0]
    return (rows[[FAMILY]].assign(applicant=best_name, sector=rows.psn_sector.fillna(""),
                                  country=rows.person_ctry_code.fillna(""))
            .dropna(subset=["applicant"]).drop_duplicates())


def read_source(source, scope):
    with ZipFile(source) as bundle:
        if bundle.read("source_run.txt").decode("utf-8").strip() != SOURCE_RUN:
            raise ValueError("The applicant archive and the saved PROD cohort must match.")
        with bundle.open("filing_years.csv") as f:
            years = pd.read_csv(f, dtype={FAMILY: "int64"})
        with bundle.open("applicant_links.csv") as f:
            links = pd.read_csv(f, keep_default_na=False, dtype={FAMILY: "int64"})
    dated = scope.merge(years, on=FAMILY, how="left", validate="one_to_one")
    periods = pd.cut(dated.filing_year, bins=[1999, 2007, 2014, 2022], labels=PERIODS)
    if not periods.astype("string").fillna("").eq(dated.period).all():
        raise ValueError("The applicant archive must provide a filing year in the saved period for every family.")
    dated["filing_year"] = dated.filing_year.astype(int)
    links = links.loc[links[FAMILY].isin(scope[FAMILY]) & links.applicant.str.strip().ne("")].drop_duplicates()
    if links.empty:
        raise ValueError("PATSTAT returned no usable applicant names for these families.")
    return dated, links


def weights_for(applicants):
    weights = applicants[[FAMILY, "applicant"]].drop_duplicates().copy()
    weights["weight"] = 1 / weights.groupby(FAMILY).applicant.transform("size")
    return weights


def harmonize_applicants(root, applicants):
    aliases = pd.read_csv(root / "data/applicant_aliases.csv")
    if not aliases.alias.is_unique or aliases.canonical.isin(aliases.alias).any():
        raise ValueError("Applicant aliases must map uniquely and directly to canonical names.")
    mapping = aliases.set_index("alias").canonical
    return applicants.assign(applicant=applicants.applicant.replace(mapping)).drop_duplicates()


def applicant_countries(links):
    known = links.loc[links.country.str.fullmatch("[A-Z]{2}")]
    counts = (known.groupby(["applicant", "country"])[FAMILY].nunique().rename("families").reset_index()
              .sort_values(["families", "country"], ascending=[False, True]))
    return counts.drop_duplicates("applicant").set_index("applicant").country.rename("recorded_country")


def concentration(dated, weighted):
    groups = with_combined(dated)
    groups = pd.concat([groups, groups.assign(period=FULL_PERIOD)], ignore_index=True)
    totals = groups.groupby(["group", "period"]).size()
    portfolios = (groups.merge(weighted, on=FAMILY).groupby(["group", "period", "applicant"]).weight.sum())
    rows = []
    for (group, period), count in totals.items():
        weights = np.sort(portfolios.get((group, period), pd.Series(dtype=float)).to_numpy())
        represented = weights.sum()
        n = len(weights)
        shares = weights / represented if n else weights
        rows.append({
            "group": group, "period": period, "families": count, "named_families": round(represented),
            "coverage_pct": 100 * represented / count, "named_applicants": n,
            "CR4_pct": 100 * shares[-4:].sum() if n else np.nan,
            "CR8_pct": 100 * shares[-8:].sum() if n else np.nan,
            "HHI": np.square(shares).sum() if n else np.nan,
            "Gini": (2 * np.dot(np.arange(1, n + 1), shares) - n - 1) / n if n else np.nan,
        })
    ranked = (portfolios.rename("fractional_families").reset_index()
              .sort_values(["fractional_families", "applicant"], ascending=[False, True]))
    ranked["share_pct"] = (100 * ranked.fractional_families
                           / ranked.groupby(["group", "period"]).fractional_families.transform("sum"))
    return pd.DataFrame(rows), ranked.groupby(["group", "period"], sort=False).head(15)


def company_panel(dated, links, weighted):
    """Choose two established portfolio sizes and recent entrants to this corpus."""
    annual = (weighted.merge(dated, on=FAMILY, validate="many_to_one")
              .groupby(["applicant", "filing_year", "group"]).weight.sum().unstack(fill_value=0)
              .reindex(columns=GROUPS[:-1], fill_value=0))
    annual["combined"] = annual.sum(axis=1)
    active = annual.reset_index()
    portfolios = active.groupby("applicant").agg(
        observed_start=("filing_year", "min"), active_years=("filing_year", "nunique"),
        total_families=("combined", "sum"), platforms=("humanoid_platform", "sum"),
        dedicated=("dedicated_component", "sum"), affine=("affine", "sum"),
    )
    companies = links.loc[links.sector.str.contains(r"\bCOMPANY\b", case=False), "applicant"]
    eligible = portfolios.loc[
        portfolios.index.isin(companies) & portfolios.active_years.ge(2)
        & portfolios.total_families.ge(3) & (portfolios.platforms + portfolios.dedicated).gt(0)
    ].reset_index()
    established = eligible.loc[eligible.observed_start.lt(ENTRY_YEAR)]
    entrants = eligible.loc[eligible.observed_start.ge(ENTRY_YEAR)]
    order = ["total_families", "applicant"]
    large = established.sort_values(order, ascending=[False, True]).head(5)
    remaining = established.loc[~established.applicant.isin(large.applicant)].copy()
    remaining["distance_from_median"] = (remaining.total_families - established.total_families.median()).abs()
    medium = remaining.sort_values(["distance_from_median", "applicant"]).head(5)
    new = entrants.sort_values(order, ascending=[False, True]).head(5)
    selected = pd.concat([
        new.assign(company_group="new_entrant"),
        medium.drop(columns="distance_from_median").assign(company_group="medium_portfolio"),
        large.assign(company_group="large_portfolio"),
    ], ignore_index=True)

    panel_index = pd.MultiIndex.from_product(
        [selected.applicant, range(FIRST_YEAR, LAST_YEAR + 1)], names=["applicant", "filing_year"]
    )
    panel = annual.reindex(panel_index, fill_value=0).reset_index().merge(
        selected[["applicant", "company_group", "observed_start"]], on="applicant", validate="many_to_one"
    )
    observed = panel.loc[panel.filing_year.ge(panel.observed_start)]
    stability = observed.groupby("applicant").combined.agg(["mean", "std", "size"])
    metrics = selected.join(stability, on="applicant")
    metrics["active_year_share_pct"] = 100 * metrics.active_years / metrics["size"]
    metrics["annual_cv"] = metrics["std"] / metrics["mean"]
    for name, window in [("families_per_year_2015_18", PREVIOUS_WINDOW), ("families_per_year_2019_22", RECENT_WINDOW)]:
        rates = panel.loc[panel.filing_year.between(*window)].groupby("applicant").combined.mean()
        metrics[name] = metrics.applicant.map(rates)
    early = metrics.families_per_year_2015_18
    late = metrics.families_per_year_2019_22
    metrics["growth_abs_per_year"] = late - early
    metrics["growth_pct"] = 100 * (late / early.where(early.gt(0)) - 1)
    return metrics.drop(columns=["mean", "std", "size"]), panel, eligible


def analyze_applicants(root, source):
    scope = read_scope(root)
    dated, people = read_source(source, scope)
    people = harmonize_applicants(root, people)
    weighted = weights_for(people)
    concentration_table, top = concentration(dated, weighted)
    companies, annual, eligible = company_panel(dated, people, weighted)
    countries = applicant_countries(people)
    top = top.join(countries, on="applicant")
    companies = companies.join(countries, on="applicant")
    results = root / "results"
    concentration_table.to_csv(results / "applicant_concentration.csv", index=False)
    top.to_csv(results / "top_applicants.csv", index=False)
    companies.to_csv(results / "company_profiles.csv", index=False)
    summary = companies.groupby("company_group", as_index=False).agg(
        companies=("applicant", "size"),
        median_growth_families_per_year=("growth_abs_per_year", "median"),
        median_active_year_share_pct=("active_year_share_pct", "median"),
        median_annual_cv=("annual_cv", "median"),
    )
    summary.to_csv(results / "company_group_summary.csv", index=False)
    annual.to_csv(results / "company_annual_panel.csv", index=False)
    eligible.to_csv(results / "company_selection_pool.csv", index=False)
    with ZipFile(source) as bundle:
        if "retrieval_routes.csv" in bundle.namelist():
            with bundle.open("retrieval_routes.csv") as hits:
                retrieval_routes(hits, scope).to_csv(results / "segmented_search_routes.csv", index=False)
    if not companies.empty:
        plot_companies(companies, annual, results / "company_patenting.png")
    metadata = {
        "source_run": SOURCE_RUN,
        "families_in_scope": len(scope),
        "families_with_named_applicant": int(weighted[FAMILY].nunique()),
        "eligible_companies": len(eligible),
        "selected_companies": companies.company_group.value_counts().to_dict(),
    }
    (results / "applicant_analysis_manifest.json").write_text(
        json.dumps(metadata, indent=2) + "\n", encoding="utf-8"
    )
    return companies


def plot_companies(companies, annual, path):
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(3, 5, figsize=(16, 8), sharex=True, sharey="row", layout="constrained")
    for row, name, title, color in zip(
        axes, ["new_entrant", "medium_portfolio", "large_portfolio"],
        ["Recent entrants", "Medium portfolios", "Large portfolios"],
        ["#216278", "#3d8d7e", "#70689c"],
    ):
        group = companies.loc[companies.company_group.eq(name)]
        for axis, firm in zip(row, group.itertuples()):
            values = annual.loc[annual.applicant.eq(firm.applicant)]
            axis.plot(values.filing_year, values.combined, color=color, lw=1.6)
            axis.set_title(fill(firm.applicant, width=26, break_long_words=False), loc="left", fontsize=8)
            axis.spines[["top", "right"]].set_visible(False)
        if not group.empty:
            peak = annual.loc[annual.applicant.isin(group.applicant), "combined"].max()
            row[0].set_ylim(0, max(1, peak * 1.08))
        row[0].set_ylabel(title)
        for axis in row[len(group):]:
            axis.set_axis_off()
    fig.suptitle("Annual patenting by selected applicants · fractional DOCDB families")
    fig.supxlabel("Filing year")
    fig.savefig(path, dpi=170)
    plt.close(fig)

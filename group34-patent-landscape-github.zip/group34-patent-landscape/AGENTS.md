# Agent guide

This repository contains a four-notebook pipeline for Group 34. Keep notebooks as short entry points and the computation in `src/`. Treat the stored applicant panel, code coverage and period tables as outputs derived from the same frozen DOCDB cohort.

## Entry points and ownership

| Stage | Notebook | Main code and inputs |
| --- | --- | --- |
| 0 · Retrieval | `00_retrieval.ipynb` | `src/thomas_retrieval.py`, `src/prod_run.py`, and both files in `config/` |
| 1 · Classification | `01_classification.ipynb` | `src/full_classification.py`, saved candidates, baseline, periods, Patent SBERT ranks and `data/` |
| 2 · Landscape | `02_landscape.ipynb` | `src/segmented_analysis.py`, classified families, assigned codes and original retrieval hits |
| 3 · Companies | `03_companies.ipynb` | `src/applicant_analysis.py`, classified families and the PATSTAT applicant archive |

The frozen source is `search_20261116T232020043130Z_THROUGH_2022_PROD`. Local notebook runs require Python 3.11+ and `requirements.txt`. Live extraction uses TIP's `epo.tipdata` package. Follow each notebook's documented switches for a refresh.

## Data contract

- A classification row has one positive integer `docdb_family_id`, one filing period and one category. The frozen export has 176,342 distinct families.
- The four landscape views are `humanoid_platform`, `dedicated_component`, `affine` and `combined`. Combined includes the first three. The strict scope includes the first two.
- Step 1 joins datasets on DOCDB ID and checks the normalized representative title. The semantic threshold only determines follow-up priority. Recorded review decisions take precedence over the automatic decision.
- Step 2 uses the exact Step 0 assigned codes and hits. It counts distinct family-code pairs by scheme and normalizes volumes by the number of years. Keep filing periods ordered as 2000–2007, 2008–2014 and 2015–2022.
- The private applicant ZIP contains `source_run.txt`, `filing_years.csv`, `applicant_links.csv` and optionally `retrieval_routes.csv`. Filing years use the minimum of PATSTAT's earliest filing year among retrieved applications. Validate the year against the family period. Applicant link fields are `docdb_family_id`, `applicant`, `sector` and `country`.
- Apply `data/applicant_aliases.csv` before assigning fractional weights. Update it only with evidence of spelling variants or a documented name change. Applicant weights sum to one per named family even if several records repeat the applicant. For company selection define age and size from the observed patent portfolio. Apply the same windows and stability metrics to the three company groups. Keep zero years in the annual panel.

## Checks before delivering changes

1. Execute the default cells of all four notebooks from the repo root.
2. Reconcile the classification counts with `full_classification_manifest.json`. For each period verify that the combined volume equals the sum of its three categories. Check code shares and coverage against their denominators.
3. When applicant inputs are available, check unique firms, five per group, 23 years per firm, positive per-family weight sums of one, and growth percentages only where the early rate is positive. For sparse data show the number of eligible firms.
4. Keep derived outputs in `results/` and local inputs under the gitignored `inputs/` folder. Use mock data for a dry run, and clearly identify any results generated from it. Never commit secrets or the PATSTAT source ZIP.

Steps 1–3 consume saved inputs. Rebuilding retrieval requires an explicit switch in Step 0 and may use substantial TIP resources.
